/***************************************************************************/
// METODOLOG�A DE LA PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//	
// RELACI�N DE PROBLEMAS 4
//
// Definici�n de la clase Punto2D (versi�n 2).
//
// Fichero: Punto2D.cpp
//
/***************************************************************************/

#include <iostream>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <string>

#include "Punto2D.h"

using namespace std;


/***************************************************************************/
/***************************************************************************/

// Dos n�meros son reales si su diferencia (en valor absoluto) es menor 
// que el valor de la constante PRECISION_SON_IGUALES

const double PRECISION_SON_IGUALES = 1e-6; // 0.000001


/***************************************************************************/
/***************************************************************************/
// Funci�n (asociada a la constante PRECISION_SON_IGUALES) que
// permite que dos n�meros reales muy pr�ximos sean considerados iguales.

bool SonIguales(double uno, double otro);

/***************************************************************************/
/***************************************************************************/


/***************************************************************************/
/***************************************************************************/
// Constructor sin argumentos.
//
// MUY IMPORTANTE: Nos vemos obligados a escribir este constructor por la
// clase "ColeccionPuntos2D": cuando act�a el constructor sin argumentos 
// de esa clase crea un vector de objetos "Punto2D" y cada elemento del  
// vector se crea usando este constructor. 
// No hace nada �til, pero debe estar.

Punto2D :: Punto2D (void) { }

/***************************************************************************/
/***************************************************************************/
// Constructor con argumentos.
//
// Par�metros: abscisaPunto y ordenadaPunto, la abscisa y ordenada, 
// 		respectivamente del punto que se est� creando.

Punto2D :: Punto2D (double abscisaPunto, double ordenadaPunto)
{
	SetCoordenadas (abscisaPunto, ordenadaPunto);
}

/***************************************************************************/
/***************************************************************************/
// M�todo Set para fijar simultaneamente las coordenadas. 
//
// Par�metros: abscisaPunto y ordenadaPunto, la abscisa y ordenada, 
// 		respectivamente del punto que se est� modificando.

void Punto2D :: SetCoordenadas (double abscisaPunto, double ordenadaPunto)
{
	x = abscisaPunto;
	y = ordenadaPunto;
}

/***************************************************************************/
/***************************************************************************/
// M�todos Get: Devuelven las coordenadas x e y, repectivamente. 

double Punto2D :: GetX (void) const
{
	return (x);
}
double Punto2D :: GetY (void) const
{
	return (y);
}

/***************************************************************************/
/***************************************************************************/
// operadores que calculan si dos datos Punto2D son iguales o distintos

bool Punto2D :: operator == (const Punto2D & otro) const
{
	return (SonIguales(x,otro.x) && SonIguales(y,otro.y)); 
}

bool Punto2D :: operator != (const Punto2D & otro) const
{
	return (! (*this == otro));
}

/***************************************************************************/
/***************************************************************************/
// Calcula la distancia Eucl�dea del punto (objeto impl�cito) a otro que 
// se recibe como argumento. 
//
// Par�metros: otro(referencia), el punto respecto al cual que se quiere 
//		calcular la distancia eucl�dea.
// Devuelve: la distancia entre los dos puntos. 

double Punto2D :: DistanciaEuclidea (const Punto2D & otro) const
{
	double dif_x = pow (x - otro.x, 2);
	double dif_y = pow (y - otro.y, 2);

	return (sqrt(dif_x + dif_y));
}

/***************************************************************************/
/***************************************************************************/
// Lee de un flujo de entrada (cin) el contenido de un Punto2D.

void Punto2D :: FromText (void)
{	
	cin >> x;
	cin >> y;
}

/***************************************************************************/
/***************************************************************************/
// Inserta en un flujo de salida (cout) el contenido de un Punto2D.

void  Punto2D :: ToText (void) const
{
	cout << ToString(); 
}

/***************************************************************************/
/***************************************************************************/
// Serializa un dato Punto2D.

string Punto2D :: ToString (void) const 
{
	string cad = to_string(x) + " " + to_string(y);	
	return (cad);
}
/***************************************************************************/


/***************************************************************************/
/***************************************************************************/
// FUNCIONES AJENAS A LA CLASE Punto2D
/***************************************************************************/
/***************************************************************************/

/***************************************************************************/
/***************************************************************************/
// Muestra el contenido de un punto 

void MuestraPunto2D (const char * msg, const Punto2D & p)
{
	cout << msg << p.ToString() << endl;
}

/***************************************************************************/
/***************************************************************************/

/***************************************************************************/
/***************************************************************************/
// Funci�n (asociada a la constante PRECISION_SON_IGUALES) que
// permite que dos n�meros reales muy pr�ximos sean considerados iguales.

bool SonIguales(double uno, double otro) 
{
	return (fabs(uno-otro) <= PRECISION_SON_IGUALES);
}

/***************************************************************************/
/***************************************************************************/

