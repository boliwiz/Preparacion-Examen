/***************************************************************************/
/***************************************************************************/
// METODOLOG�A DE LA PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 4
//
// Definici�n de la clase Polilinea (versi�n 2).
//
// Fichero: Polilinea.cpp
//
/***************************************************************************/
/***************************************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>

#include "Punto2D.h"
#include "Polilinea.h"

using namespace std;

/***************************************************************************/
/***************************************************************************/
// Constructor sin argumentos. Crea una PoliLinea vac�a

PoliLinea :: PoliLinea (void) : usados (0), datos(0) { }

/***************************************************************************/
/***************************************************************************/
// Constructor a partir de un punto. 
//
// Recibe: nuevo_punto, el �nico punto que forma la nueva colecci�n. 

PoliLinea :: PoliLinea (const Punto2D & nuevo_punto) : usados (0), datos(0)
{
	Aniade (nuevo_punto);
}

/***************************************************************************/
/***************************************************************************/
// Constructor de copia

PoliLinea :: PoliLinea (const PoliLinea & otro)
{
	ReservarMemoria (otro.usados);
	CopiarDatos (otro);
}

/***************************************************************************/
/***************************************************************************/
// Destructor

PoliLinea :: ~PoliLinea (void)
{
	LiberarMemoria();
}

/***************************************************************************/
/***************************************************************************/
// Devuelve el n�mero de puntos que componen la PoliLinea.

int PoliLinea :: NumPuntos (void) const
{
	return (usados);
}

/***************************************************************************/
/***************************************************************************/
// Consulta si la PoliLinea est� vac�a

bool PoliLinea :: EstaVacia (void) const
{	
	return (usados==0);
}

/***************************************************************************/
/***************************************************************************/
// Elimina todos los datos Punto2D de la Polilinea. Queda vac�a.

void PoliLinea :: EliminaTodos (void)
{
	LiberarMemoria (); 
}

/***************************************************************************/
/***************************************************************************/
// Serializa un dato PoliLinea.

string PoliLinea :: ToString (void) const 
{

	string cad = to_string(usados) + "\n";

	for (int i=0; i<usados; i++) 

		cad = cad + datos[i].ToString() + "\n"; 

	return (cad); 
} 

/***************************************************************************/
/***************************************************************************/
// Operador de asignaci�n. 
// M�todo para hacer una copia profunda desde la PoliLinea expl�cita 
// "otra" en la PoliLinea impl�cita.
// Par�metros: otra (referencia), referencia al objeto expl�cito
// El contenido de la Polilinea impl�cita se pierde, se sustituye por una  
// copia del contenido de "otra". 

PoliLinea & PoliLinea :: operator = (const PoliLinea & otra)
{
    if (this != &otra) { // Evitar autoasignaci�n

        // Libera la memoria ocupada
		LiberarMemoria ();

        // Reserva de memoria para los valores de la PoliLinea
		ReservarMemoria (otra.usados);

        // Copia el contenido de la PoliLinea y los campos privados
		CopiarDatos (otra);
    }
    
    return (*this);  // Objeto implicito: parte
                     // izquierda de la asignaci�n
}

/***************************************************************************/
/***************************************************************************/
// Metodo de acceso individual a elementos: Operador []
// Metodo de escritura / lectura
// Par�metros: indice, la posici�n a la que se accede.  	
// Consulta � modifica el valor de un componente de la Polilinea dado 
// por su posici�n (para devolver un Punto2D o sustituirlo por otro).  
// Si se utiliza como rvalue se emplea para consulta. Si se utiliza  
// como lvalue se emplea para modificaci�n.
// Devuelve una referencia al dato Punto2D que est� en la casilla "indice".
//
// PRE: 1 <= indice <= usados

Punto2D & PoliLinea :: operator[] (const int indice)
{
	return el_valor(indice); 
}

Punto2D & PoliLinea :: operator[] (const int indice) const
{
	return el_valor(indice); 
}

/***************************************************************************/
/***************************************************************************/
// Calcula si dos PoliLinea son iguales 
// Dos datos PoliLinea son iguales si tienen los mismos puntos y est�n 
// en el mismo orden, independientemente de que se empiece por el primero 
// o el �ltimo. 
// Par�metros: otra (referencia), la PoliLinea que se quiere comparar con el 
//		objeto impl�cito. 
// Devuelve: true, si se consideran iguales los dos objetos.

bool PoliLinea :: operator == (const PoliLinea & otra) const
{ 
	return (EsIgualA(otra));
}

/***************************************************************************/
/***************************************************************************/
// Calcula si dos PoliLinea son distintas 
// Dos datos PoliLinea son iguales si tienen los mismos puntos y est�n 
// en el mismo orden, independientemente de que se empiece por el primero 
// o el �ltimo. Dos PoliLinea son distintas si no son iguales. 
// Par�metros: otra (referencia), la PoliLinea que se quiere comparar con el 
//		objeto impl�cito. 
// Devuelve: true, si se consideran distintas los dos objetos.

bool PoliLinea :: operator != (const PoliLinea & otra) const
{
	return !((*this) == otra); // Operator ==
}

/***************************************************************************/
/***************************************************************************/
// Operador binario +    Versi�n 1: [PoliLinea] + [PoliLinea] 
//
// Calcula y devuelve una NUEVA PoliLinea.
// Concatena las dos PoliLinea en una nueva. Los puntos de la segunda se 
// a�aden (en el mismo orden en una copia de la primera).   
// Par�metros: p1 (referencia), primer dato PoliLinea.  
//             p2 (referencia), segundo dato PoliLinea.  
// POST: Los dos datos PoliLinea NO se modifican.
// Devuelve: una dato PoliLInea, resultado de concatenar "p1" y "p2".

PoliLinea operator + (const PoliLinea & p1, const PoliLinea & p2)
{

	PoliLinea nueva (p1); // Act�a el constructor de copia

	for (int i=0; i<p2.usados; i++)
		nueva.Aniade (p2.datos[i]);

	return (nueva);
}

/***************************************************************************/
/***************************************************************************/
// Operador binario +      Versi�n 2: [PoliLinea] + [Punto2D] 
//
// Calcula y devuelve una NUEVA PoliLinea.
// A�ade un dato Punto2D al final de una PoliLinea.   
// Par�metros: pol (referencia), la PoliLinea.  
//             punto (referencia), el Punto2D que se a�ade.  
// POST: No se modifican "pol" ni "punto".
// Devuelve: una dato PoliLInea, resultado de a�adir "punto" a "pol".

PoliLinea operator + (const PoliLinea & pol, const Punto2D & punto)
{
	PoliLinea nueva (punto);

	return (pol + nueva); // Versi�n 1: [PoliLinea] + [PoliLinea]
}

/***************************************************************************/
/***************************************************************************/
// Operador binario +      Versi�n 3: [Punto2D] + [PoliLinea] 
//
// Calcula y devuelve una NUEVA PoliLinea.
// Inserta un dato Punto2D al principio de una PoliLinea.   
// Par�metros: pol (referencia), la PoliLinea.  
//             punto (referencia), el Punto2D que se inserta.  
// POST: No se modifican "pol" ni "punto".
// Devuelve: una dato PoliLInea, resultado de insertar "punto" en "pol".

PoliLinea operator + (const Punto2D & punto, const PoliLinea & pol)
{
	PoliLinea nueva (punto);

	return (nueva + pol); // Versi�n 1: [PoliLinea] + [PoliLinea]
}

/***************************************************************************/
/***************************************************************************/
// Operador combinado +=
// A�ade un Punto2D a la Polilinea.
// Par�metros: nuevo_punto (referencia), el punto que se va a a�adir.
// Devuelve: una referencia a la matriz impl�cita modificada.

PoliLinea & PoliLinea :: operator += (const Punto2D & nuevo_punto)
{
	(*this).Aniade (nuevo_punto);

	return (*this);
}

/***************************************************************************/
/***************************************************************************/
// Lee de un flujo de entrada (cin) el contenido de una PoliLinea.

void PoliLinea :: FromText (void)
{	
	// Limpiar el objeto: Liberar memoria reservada previamente
	LiberarMemoria ();

	// Lectura del num. de puntos de la polil�nea

	int num_puntos;
	cin >> num_puntos;

	double punto_x, punto_y;

	for (int cont_puntos = 0; cont_puntos<num_puntos; cont_puntos++) {

		// Leer coordenada x
		cin >> punto_x;

		// Leer coordenada y
		cin >> punto_y;

		// Crea un dato Punto2D y lo rellena con los valores leidos
		Punto2D un_punto (punto_x, punto_y);

		// A�ade el punto a la colecci�n
		Aniade (un_punto); 

	} // for

}

/***************************************************************************/
/***************************************************************************/
// Inserta en un flujo de salida (cout) el contenido de una PoliLinea.

void PoliLinea :: ToText (void) const 
{
	cout << ToString();
}

/***************************************************************************/
/***************************************************************************/



/***************************************************************************/
/***************************************************************************/
// METODOS PRIVADOS DE LA CLASE Polilinea
/***************************************************************************/
/***************************************************************************/

/***************************************************************************/
/***************************************************************************/
// Pide memoria para guardar "num_casillas" datos	

void PoliLinea :: ReservarMemoria (const int num_casillas)
{
	datos = new Punto2D[num_casillas]; 
}

/***************************************************************************/
/***************************************************************************/
// Libera memoria

void PoliLinea :: LiberarMemoria (void)
{
	if (datos) { 

		delete [] datos;

		datos = 0;
		usados = 0; 
	}
}

/***************************************************************************/
/***************************************************************************/
// Copiar datos desde otro objeto de la clase
// PRE: Se ha reservado memoria para los PoliLinea

void PoliLinea :: CopiarDatos (const PoliLinea & otra)
{
	// Copia los valores de los campos privados desde "otra" 
	usados = otra.usados;	

	// Copiar los valores 
	memcpy (datos, otra.datos, usados*sizeof(Punto2D));
}

/***************************************************************************/
/***************************************************************************/
// M�todo PRIVADO compartido por: 
// 		Punto2D & Valor (const int indice);
// 		Punto2D & Valor (const int indice) const;
// para evitar la duplicidad de c�digo.
// 
// Devuelve una referencia a un dato Punto2D de la PoliLinea, 
// dada su posici�n. 
//
// PRE: 1 <= indice <= usados

Punto2D & PoliLinea :: el_valor (int indice) const
{
	return (datos [indice-1]);
}

/***************************************************************************/
/***************************************************************************/
// Calcula si dos PoliLinea son iguales 
// Dos datos PoliLinea son iguales si tienen los mismos puntos y est�n 
// en el mismo orden, independientemente de que se empiece por el primero 
// o el �ltimo. 
// Par�metros: otra (referencia), la PoliLinea que se quiere comparar con el 
//		objeto impl�cito. 
// Devuelve: true, si se consideran iguales los dos objetos.

bool PoliLinea :: EsIgualA (const PoliLinea & otra) const
{ 
	bool iguales = (usados == otra.usados);

	// Si no tienen los mismos puntos hemos terminado

	if (iguales) {
 
		bool iguales1 = true;

		// Recorrer las dos de forma directa
		int pos=0; // com�n para las dos

		while ((pos != usados) && (iguales1)) {

			// �Punto2D != Punto2D?
			
			if (datos[pos] != otra.datos[pos]) // operator != de Punto2D
				iguales1 = false;
			else 
				pos++;

		} // while ((pos != usados) && (iguales1))

		// Si son iguales de forma directa no es preciso seguir --> iguales

		if (!iguales1) {  // Si no son iguales de forma directa

			bool iguales2 = true;

			// Recorrer la primera de forma directa y la otra a la inversa
			int pos=0;
			int pos_otra=otra.usados-1;

			while ((pos != usados) && (iguales2)) {
			
				// �Punto2D != Punto2D? con operator != de Punto2D

				if (datos[pos] != otra.datos[pos_otra]) 
					iguales2 = false;
				else {
					pos++;
					pos_otra--;
				}

			} // while ((pos != usados) && (iguales2)) 

			// Si son iguales de forma inversa, son iguales 
			iguales = iguales2;

		} // if (!iguales1)

		else iguales = true; 
	}

	return (iguales);
}

/***************************************************************************/
/***************************************************************************/
// A�ade un Punto2D a la Polilinea.
// Par�metros: nuevo_punto (referencia), el punto que se va a a�adir.

void PoliLinea :: Aniade (const Punto2D & nuevo_punto)
{
	// Pedir memoria para el nuevo almacen 
	Punto2D * tmp = new Punto2D[usados+1]; 

	// Copiar los datos 
	memcpy (tmp, datos, usados*sizeof(Punto2D)); 
	
	// Liberar la memoria del antiguo almac�n
	delete [] datos; 

	// Reasignacion del puntero "datos" paara que referencie a la 
	// nueva zona de memoria ampliada y con los datos copiados. 
	datos = tmp; 

	datos [usados] = nuevo_punto;
	usados++;
}

/***************************************************************************/
/***************************************************************************/
