/***************************************************************************/
/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// RELACION DE PROBLEMAS 4
//
// Clase "Lista"
//
// Representaci�n: b�sica, nodos enlazados el Heap.
// Los datos son de tipo "TipoBaseLista"
//
// Definici�n de la clase Lista (versi�n 2).
//
// Incluye: 
//		* constructor de copia
//		* destructor
//		* Operador =
// 		* Operadores de acceso
//		* Operadores varios
//
// Fichero: Lista.cpp
//
/***************************************************************************/
/***************************************************************************/

#include <iostream>
#include <iomanip>
#include <cstring>
#include <string>

#include "TipoBase_Lista.h"
#include "Lista.h"

using namespace std; 

/***************************************************************************/
/***************************************************************************/
// Constructor unificado:
//	a) Constructor sin argumentos, que crea una lista vac�a.
//  b) Constructor con un argumento, que crea una lista con un n�mero de 
//		nodos indicado en el argumento.
//	c) Constructor con dos argumentos, que crea una lista con un n�mero 
//		de nodos indicado en el primer argumento. Inicia todos los nodos 
//		de la lista al valor indicado en el segundo argumento.
//
// Crea una lista enlazada con "num_nodos" nodos. Inicializa todos 
// los nodos a un valor com�n, el indicado en el par�metro "valor". 
// Par�metros:
//  	num_nodos, n�mero de nodos que se van a crear. 
//		valor, valor com�n que se copiar� en las casillas. 
// Devuelve: un dato de tipo Lista.
//
// PRE:  num_nodos >= 0 
// NOTA: Si num_nodos==0 la lista queda vac�a. 

Lista :: Lista (int num_nodos, TipoBaseLista valor) 
               : primero(0), tamanio(num_nodos)
{
	ReservarMemoria (tamanio);
	Ecualiza (valor);
}
	
/***************************************************************************/		
// Constructor de copia

Lista :: Lista (const Lista & otro)
{	
	// Reservar memoria para los nodos de la lista
	ReservarMemoria (otro.tamanio);

	// Copiar campos privados y los valores de la lista
	CopiarDatos (otro);
}		
	
/***************************************************************************/
// Destructor

Lista :: ~Lista (void)
{
    LiberarMemoria ();
}

/***************************************************************************/
// Consulta si la lista esta vacia
// Devuelve: true si la lista esta vacia. 

bool Lista :: EstaVacia(void) const
{
	return (tamanio == 0);
}	

/***************************************************************************/
// Devuelve el n�mero de nodos de la lista

int Lista :: Tamanio(void)	const
{
	return tamanio;
}

/***************************************************************************/
// Elimina todos los valores de la lista. 
// POST: EstaVacia() == true

void Lista :: EliminaTodos  (void)
{
	LiberarMemoria(); 
	tamanio = 0; 
}

/***************************************************************************/
/***************************************************************************/
// Ecualizar una lista: cambia todos los todos valores de la lista y los 
// fija todos iguales e iguales a "valor".
// Par�metros: valor, el valor com�n  que se escribir� en todos  
//					los nodos (por defecto, VALOR_DEF_LISTA)

void Lista :: Ecualiza (const TipoBaseLista valor)
{
	TipoNodo * p = primero; // Apuntar al primero.

	for(int i = 0; i < tamanio; i++) {
		p->info = valor; // Inicializar nodo.
		p = p->sig;		 // Adelantar "p".
	}						
}

/***************************************************************************/
/***************************************************************************/
// Busca la posici�n de un valor. 
// Par�metros: valor, el valor buscado. 
// Devuelve la posici�n del primer valor coincidente con "valor", 
//      o -1 si no se encuentra.
// Posiciones: 1, 2, ..., Tamanio()

int Lista :: Buscar (TipoBaseLista valor) const
{
    TipoNodo * p = primero;

    bool sigo = true;
    bool encontrado = false;

	int pos = 0;
    	
    while ((p!=0) && sigo) {
    	
		pos++; // Actualizar posici�n

        if (p->info == valor) {
            sigo = false;
            encontrado = true;
        }
        else 
            p = p->sig;
	}
	
	return (encontrado ? (pos) : -1); 
}	

/***************************************************************************/    
/***************************************************************************/
// Inserta un nuevo elemento en la posici�n "pos_insertar"
//
// PRE: 1 <= pos_insertar <= tamanio+1
// El criterio seguido para especificar una posicion ser� : 
// 1 -> primero, 2 -> segundo,...
// Nota: Si pos_insertar == tamanio+1, el resultado es id�ntico a la 
// 		 ejecuci�n del m�todo AniadeValor()

void  Lista :: Inserta (TipoBaseLista val, int pos_insertar)
{
	TipoNodo * ant = primero;
	TipoNodo * resto = primero;

	// Crear el nodo que se va a insertar e iniciarlo
	TipoNodo * nuevo = new TipoNodo; 
	nuevo->info = val; 

	// Buscar el sitio que le corresponde 
	for (int i=1; i<pos_insertar; i++) { 
		ant = resto; 
		resto = resto->sig;
	}

	if (pos_insertar==1)   // El nuevo nodo sera el primero 
		primero = nuevo;
	else		  // Enlazar el nuevo con el anterior 
		ant->sig = nuevo;

	nuevo->sig = resto; // Enlazar el nuevo nodo con el resto

	tamanio++; // Actualizar tamanio
}

/***************************************************************************/
/***************************************************************************/
// Eliminar el nodo cuya posici�n es "pos_borrar".
// El criterio seguido para especificar una posicion ser�: 
// 1 -> primero, 2 -> segundo,...	
// PRE: 1 <= pos_borrar <= Tamanio()

void  Lista :: Elimina (int pos_borrar) 
{
	TipoNodo * ant = primero;
	TipoNodo * pos = primero;

	// Colocar "ant" y "act" 
	for (int i=1; i<pos_borrar; i++) { 
		ant = pos; 
		pos = pos->sig;
	}

	// "pos" apunta al nodo que se va a borrar
	// "ant" apunta al nodo anterior

	if (pos_borrar==1)   // Saltar el primero 
		primero = primero->sig;
	else 
		ant->sig = pos->sig;
		// Enlazar el anterior con el siguiente 

	delete pos; // Borrar nodo
	
	tamanio--;  // Actualizar tamanio
}

/***********************************************************************/
/***********************************************************************/
// Devuelve un string con el resultado de "serializar" una lista.
// Par�metros: msg, mensaje que precede al contenido de la lista. 

string Lista :: ToString (const char * const msg)
{
	string cad = "--------------------------------------------------\n";
	cad = cad + msg + "\n";
	cad = cad + "Num. nodos = " + to_string(tamanio) + "\n";

	if (tamanio > 0)  {

		cad = cad + "Valores almacenados en la lista: \n"; 
		cad = cad + "{ ";

		TipoNodo * p; 
		int pos;

		// Se evita el �ltimo nodo 

		for (p=primero, pos=1; pos<tamanio; pos++, p=p->sig)  {
			#ifdef INT
			cad = cad + to_string(p->info);	
			#else
			#ifdef CHAR
			cad = cad + p->info;	
			#else
			#ifdef DOUBLE
			cad = cad + to_string(p->info);	
			#endif
			#endif
			#endif

			cad = cad + ", ";
		}
			
		// Ultimo nodo

		#ifdef INT
		cad = cad + to_string(p->info);	
		#else
		#ifdef CHAR
		cad = cad + p->info;	
		#else
		#ifdef DOUBLE
		cad = cad + to_string(p->info);	
		#endif
		#endif
		#endif

		cad = cad + "}\n";  
	}
	else 
		cad = cad + "Lista vacia\n";

	cad = cad + "--------------------------------------------------\n\n";

	return cad;
}



/***************************************************************************/
/***************************************************************************/
// Operador de asignaci�n 

Lista & Lista :: operator = (const Lista & otro)
{
    if (this != &otro)  // Evitar autoasignaci�n
	{
        // Libera la memoria ocupada
        LiberarMemoria();

        // Reserva de memoria para los valores de la matriz
		ReservarMemoria (otro.tamanio);

        // Copia el contenido de la matriz y los campos privados
        CopiarDatos(otro);
    }
    return (*this);  // Objeto implicito: parte
                     // izquierda de la asignaci�n
}

/***************************************************************************/
/***************************************************************************/
// Operador de asignaci�n 

Lista & Lista :: operator = (const TipoBaseLista & valor)
{
	// Escribir "valor" en todos los nodos
    Ecualiza (valor);
 
    return (*this);  // Objeto implicito: parte
                     // izquierda de la asignaci�n
}	

/***************************************************************************/
/***************************************************************************/
// Metodo de acceso individual a elementos: operator [] y operator()
// Metodo de escritura / lectura
// Si se utiliza como rvalue se emplea para consulta. Si se utiliza  
// como lvalue se emplea para modificaci�n.
//
// Par�metros: pos, la posici�n (n�mero de nodo) a la que se accede.  	
// 		El criterio seguido para especificar una posicion ser� : 
// 		1 -> primero, 2 -> segundo,...
//
// PRE: 1 <= posicion <= Tamanio() 	

TipoBaseLista & Lista ::  operator [] (const int posicion)
{
	return el_valor(posicion); 
}

TipoBaseLista & Lista ::  operator [] (const int posicion) const
{
	return el_valor(posicion); 
}

TipoBaseLista & Lista ::  operator () (const int posicion)
{
	return ((*this)[posicion]); // Llamada a operator [] - por gusto
}

TipoBaseLista & Lista ::  operator () (const int posicion) const
{
	return ((*this)[posicion]); // Llamada a operator [] - por gusto
}

/***************************************************************************/
/***************************************************************************/
// Operador combinado +=
// A�ade "valor", un dato TipoBaseLista al final de la lista

Lista & Lista :: operator += (const TipoBaseLista valor)
{
	// A�ade (al final) un nodo con "valor"
	AniadeValor (valor); 

	return (*this);
}

/***************************************************************************/
// Operador combinado -=
// Elimina la primera aparici�n de "valor" en la lista
// Si "valor" no est� en la lista no se hace nada.  

Lista & Lista :: operator -= (const TipoBaseLista valor)
{
	// Elimina el primer nodo con "valor"
	EliminarValor (valor);

	return (*this);
}

/***************************************************************************/
// Operador binario +   Versi�n 1: [Lista] + [Lista] 
//
// Calcula y devuelve una NUEVA Lista.
// Concatena las dos Lista en una nueva. Los nodos de la segunda se 
// a�aden (en el mismo orden en una copia de la primera).   
// Par�metros: l1 (referencia), primer dato Lista.  
//             l2 (referencia), segundo dato Lista.  
// POST: Los dos datos Lista NO se modifican.
// Devuelve: una dato Lista, resultado de concatenar "l1" y "l2".

Lista  operator + (const Lista & l1, const Lista & l2)
{
	// "resultado" ser� inicialmente una copia de "l1"
	Lista resultado (l1);

	// Recorrer "l2" completamente, copiando todos los valores 
	// de "l2" (en el mismo orden en que est�n en "l2") en 
	// "resultado", siempre al final.

	TipoNodo * p_otro = l2.primero; // Primer nodo de "l2"

	for (int i = 1; i <= l2.tamanio; i++) {

		// "valor" es el contenido del nodo actual de "l2"
		TipoBaseLista valor = p_otro->info;	

		// A�ade (al final) un nodo con "valor"
		resultado.AniadeValor (valor); 

		// Apuntar al siguiente nodo de "l2" 
		p_otro = p_otro->sig;	
	}			

	return (resultado);
}

/***************************************************************************/
// Operador binario + (2)     Versi�n 2: [Lista] + [TipoBaseLista] 
//
// Calcula y devuelve una NUEVA Lista.
// A�ade un dato TipoBaseLista al final de una Lista.   
// Par�metros: l (referencia), la Lista.  
//             valor, el dato TipoBaseLista que se a�ade
// POST: No se modifica "l".

Lista  operator + (const Lista & l, const TipoBaseLista valor)
{
	Lista nueva (1, valor);

	return (l + nueva); // Versi�n 1: [Lista] + [Lista]

	/*	
	// "resultado" ser� inicialmente una copia de "l"
	Lista resultado (l); 

	// A�ade (al final) un nodo con "valor"
	resultado.AniadeValor (valor);	

	return (resultado);
	*/
}

/***************************************************************************/
/***************************************************************************/
// Operador binario      Versi�n 2: [TipoBaseLista] + [Lista] 
//
// Calcula y devuelve una NUEVA Lista.
// Inserta un dato TipoBaseLista al principio de una Lista.   
// Par�metros: valor, el dato TipoBaseLista que se a�ade
//			   l (referencia), la Lista.  
// POST: No se modifica "l".

Lista  operator + (const TipoBaseLista valor, const Lista & l)
{
	// "resultado" ser� inicialmente una copia de "l"
	Lista resultado (l); 

	// A�ade (al principio) un nodo con "valor"
	resultado.Inserta (valor, 1);

	return (resultado);
}

/***************************************************************************/
/***************************************************************************/
// Operador binario -  Versi�n 1: [Lista] - [Lista] 
//
// Calcula y devuelve una NUEVA Lista.
// Elimina de una copia de la primera lista la primera ocurrencia de todos 
// los valores que est�n en la segunda.   
// Par�metros: otra (referencia), Lista expl�cita.  
// POST: Los dos datos Lista NO se modifican.

Lista  Lista :: operator - (const Lista & otra)
{
	// "resultado" ser� inicialmente una copia del objeto impl�cito
	Lista resultado = (*this); 

	for (int pos=1; pos<=otra.tamanio; pos++) {
		
		resultado.EliminarValor (otra[pos]); // operator []
	}
		
	return (resultado);
}

/***************************************************************************/
/***************************************************************************/
// Operador binario -  Versi�n 2: [Lista] - [TipoBaseLista] 
//
// Calcula y devuelve una NUEVA Lista.
// Elimina de una copia de la primera lista la primera ocurrencia del 
// valor dado.   
// Par�metros: valor, el valor a eliminar d ela lista.
// POST: La lista NO se modifica.

Lista  Lista :: operator - (const TipoBaseLista valor)
{
	// "resultado" ser� inicialmente una copia del objeto impl�cito
	Lista resultado = (*this); 

	// Elimina el primer nodo con "valor"
	resultado.EliminarValor (valor); 	

	return (resultado);
}
	
/***************************************************************************/
/***************************************************************************/
// Operador == 
// Se sigue el criterio de orden de una cadena cl�sica 

bool Lista :: operator == (const Lista & otro) const
{
	// Si las dimensiones son diferentes, las listas son distintas
	bool iguales = (tamanio == otro.tamanio);
	
	if (iguales) { // Comparar nodo a nodo

		for (int pos = 1; (pos<=tamanio) && iguales; pos++) 			
			if ((*this)[pos] != otro[pos]) // operator []
				iguales = false;
	}
	return (iguales);
}

/***************************************************************************/
/***************************************************************************/
// Operador != 
// Se sigue el criterio de orden de una cadena cl�sica 

bool Lista::operator != (const Lista & otro) const
{
	return !((*this) == otro);
}

/***************************************************************************/
/***************************************************************************/
// Operador > 

bool Lista::operator > (const Lista & otro) const
{
	int fin1 = tamanio;			// N�mero de nodos de las  
	int fin2 = otro.tamanio;	// dos lista a commparar
	

	// Recorrer las dos listas mientras queden elementos por 
	// explorar y contin�en siendo iguales en las dos listas 

	int pos=1; // Posici�n com�n en ambas listas 

	bool iguales = true; 

	TipoBaseLista valor_este; // valor del nodo del objeto impl�cito 
	TipoBaseLista valor_otro; // valor del nodo del objeto "otro"

	while ((pos<=fin1) && (pos<=fin2) && (iguales)) {

		valor_este = (*this)[pos]; 	// operator []
		valor_otro = otro[pos];		// operator []

		if (valor_este != valor_otro) iguales = false;
		else pos++;
	}

	bool mayor = false;

	// No se ha alcanzado el final en ninguna lista, pero se ha 
	// encontrado una discrepancia
	if ((pos<=fin1) && (pos<=fin2) && (valor_este > valor_otro)) 
		mayor = true; 

	// Se ha agotado la lista "otro"
	if ((pos<=fin1) && (pos>fin2)) 
		mayor = true; 

	return (mayor);
}

/***************************************************************************/
/***************************************************************************/
// Operador <

bool Lista::operator < (const Lista & otro) const
{
	return (!(((*this) > otro) || ((*this) == otro)));
}

/***************************************************************************/
/***************************************************************************/
// Operador >=

bool Lista::operator >= (const Lista & otro) const
{
	return (((*this) > otro) || ((*this) == otro));
}

/***************************************************************************/
/***************************************************************************/
// Operador <=

bool Lista::operator <= (const Lista & otro) const
{
	return (((*this) < otro) || ((*this) == otro));
}

/***************************************************************************/
/***************************************************************************/


/***************************************************************************/
/***************************************************************************/
// METODOS PRIVADOS
/***************************************************************************/
/***************************************************************************/

/***************************************************************************/
/***************************************************************************/
// Pide memoria para "num_elementos" nodos
// PRE: num_elementos > 0

void  Lista :: ReservarMemoria (int num_elementos)
{
	if (num_elementos > 0) {
		
		primero = new TipoNodo;		// Crear primer nodo.

		TipoNodo * ultimo = primero; // Apuntar al �ltimo.
		TipoNodo * p;

		for (int i = 1; i < num_elementos; i++) {

			p = new TipoNodo;	// Crear un nodo.
			ultimo->sig = p;	// Enlazar el nuevo nodo. 
			ultimo = p;			// Pasa a ser el �ltimo.
		}						

		ultimo->sig = 0; // Finalizar la lista

		tamanio = num_elementos;
	} 
	else { // Lista vac�a

		primero = 0; // MUY IMPORTANTE
		tamanio = 0;
	}
}

/***************************************************************************/
/***************************************************************************/
// Liberar memoria

void  Lista :: LiberarMemoria (void)
{
	if (primero !=0) {
		
		TipoNodo *p = primero; // Colocar "p" al principio

		while (primero->sig != 0) {

			primero = primero->sig;  // Nuevo "primero"
			delete p;     // Borrar el antiguo primero
			p = primero;  // Actualizar "p"
		}

		delete primero; // Borrar el �nico que queda
		
		// Lista vac�a
		
		primero = 0; // MUY IMPORTANTE
		tamanio = 0;
	}
}

/***************************************************************************/
/***************************************************************************/
// Copiar datos desde otro objeto de la clase
// PRE: Se ha reservado memoria para los datos

void Lista :: CopiarDatos (const Lista & otro)
{
    // Copia los campos privados

    tamanio = otro.tamanio; // Copia el n�m. de nodos

    // Copia el contenido de los nodos

	TipoNodo * p_este = primero; 
	TipoNodo * p_otro = otro.primero; 

	for(int i = 0; i < tamanio; i++) {

		// Copiar valor
		p_este->info = p_otro->info; 

		// Adelantar punteros
		p_este = p_este->sig;		 
		p_otro = p_otro->sig;		 
	}	
}

/***************************************************************************/
/***************************************************************************/
// M�todo PRIVADO compartido por: 
// 		TipoBaseLista & operator[] (int pos);
// 		TipoBaseLista & operator[] (int pos) const;
// para evitar la duplicidad de c�digo.
// 
// Devuelve una referencia al campo info de un nodo, dado por su posici�n. 
//
// Par�metros: pos, la posici�n (n�mero de nodo) a la que se accede.  	
// 		El criterio seguido para especificar una posicion ser� : 
// 		1 -> primero, 2 -> segundo,...

TipoBaseLista & Lista :: el_valor (int pos) const
{
	int num_elementos = tamanio;

	TipoNodo * p; 
	int posic;

	for (p=primero,posic=1; posic<pos; posic++) p=p->sig;

	return p->info; 
}

/***************************************************************************/
/***************************************************************************/
// Aniade (al final) un nuevo elemento

void  Lista :: AniadeValor (TipoBaseLista valor)
{
	// Crear un nuevo (�ltimo) nodo y rellenar sus campos
	TipoNodo * nuevo = new TipoNodo;
	nuevo->info = valor;
	nuevo->sig = 0;

	if (primero != 0) {  // La lista no est� vac�a

		// Buscar el �ltimo nodo
		TipoNodo * p = primero;
		
		for(int i=1; i<tamanio; i++)
			p = p->sig;

		// "p" apunta al �ltimo nodo	
					
		p->sig = nuevo;
	}
	else { // La lista estaba vac�a
		primero = nuevo; 
	}
	
	tamanio++;
}

/***************************************************************************/
/***************************************************************************/
// Borra el primer nodo que contiene el valor "valor"

void Lista :: EliminarValor (TipoBaseLista valor)
{
	int pos = Buscar (valor);

	// Si pos > 0 se encontr� el alumno buscado: eliminarlo
	if (pos > 0) Elimina (pos);
}
    

/***************************************************************************/
/***************************************************************************/
// Otras funciones no pertenecientes a la clase
/***************************************************************************/
/***************************************************************************/

/***************************************************************************/
// Muestra el contenido de una lista, precedido del mensaje "msg"
void PintaLista (const Lista & l, const char * msg)
{
	cout << endl; 
	cout << "--------------------------------------------------" << endl;
	cout << msg << endl;

	int tamanio = l.Tamanio();

	for(int pos=1; pos<=tamanio; pos++) {
 

		TipoBaseLista valor = l[pos];  

		#ifdef INT
		cout << setw(ANCHO_LISTA) << valor;	
		#else
		#ifdef CHAR
		cout << setw(ANCHO_LISTA) << valor;	
		#else
		#ifdef DOUBLE
		cout << setw(ANCHO_LISTA) << setprecision(DECIMALES_LISTA) << valor;	
		#endif
		#endif
		#endif

		cout << ((pos != tamanio)?" - ":"");

	}	
	cout << endl; 

	cout << "--------------------------------------------------" << endl;  
	cout << endl;
}

/***************************************************************************/
/***************************************************************************/
