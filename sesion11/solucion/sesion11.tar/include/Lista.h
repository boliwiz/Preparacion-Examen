/***************************************************************************/
/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// RELACION DE PROBLEMAS 4
//
// Clase "Lista"
//
// Representaci�n: b�sica, nodos enlazados el Heap.
// Los datos son de tipo "TipoBaseLista"
//
// Declaraci�n de la clase Lista (versi�n 2).
//
// Incluye: 
//		* constructor de copia
//		* destructor
//		* Operador =
// 		* Operadores de acceso
//		* Operadores varios
//
// Fichero: Lista.h
//
/***************************************************************************/
/***************************************************************************/

#ifndef LISTA
#define LISTA

#include <string>

#include "TipoBase_Lista.h"

using namespace std;

/***************************************************************************/
// Definiciones de tipos

struct TipoNodo 		// Tipo de cada nodo
{
	TipoBaseLista   info;	// Valor guardado en el nodo
	TipoNodo * sig;	  		// Puntero al siguiente
};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

class Lista 
{


private:
	
	TipoNodo * primero; // Puntero al primer nodo 

	// PRE: tamanio >= 0
	
	int tamanio;		// N�mero de nodos
	
public:

	/***********************************************************************/
	/***********************************************************************/
	// Constructor unificado:
	//	a) Constructor sin argumentos, que crea una lista vac�a.
	//  b) Constructor con un argumento, que crea una lista con un n�mero de 
	//		nodos indicado en el argumento.
	//	c) Constructor con dos argumentos, que crea una lista con un n�mero 
	//		de nodos indicado en el primer argumento. Inicia todos los nodos 
	//		de la lista al valor indicado en el segundo argumento.
	//
	// Crea una lista enlazada con "num_nodos" nodos. Inicializa todos 
	// los nodos a un valor com�n, el indicado en el par�metro "valor". 
	// Par�metros:
	//  	num_nodos, n�mero de nodos que se van a crear. 
	//		valor, valor com�n que se copiar� en las casillas. 
	// Devuelve: un dato de tipo Lista.
	//
	// PRE:  num_nodos >= 0 
	// NOTA: Si num_nodos==0 la lista queda vac�a. 

	Lista (int num_nodos=0, TipoBaseLista valor=VALOR_DEF_LISTA);

	/***********************************************************************/
	// Constructor de copia

	Lista (const Lista & otro);
	
	/***********************************************************************/
    // Destructor

    ~Lista (void);

	/***********************************************************************/
    // Consulta si la lista esta vacia
    // Devuelve: true si la lista esta vacia. 

	bool EstaVacia (void) const;
	
	/***********************************************************************/
	// Devuelve el numero de elementos
	
	int  Tamanio (void) const;

	/***********************************************************************/
	// Elimina todos los valores de la lista. 
	// POST: EstaVacia() == true

	void EliminaTodos (void);

	/***********************************************************************/
	/***********************************************************************/
	// Ecualizar una lista: cambia todos los todos valores de la lista y los 
	// fija todos iguales e iguales a "valor".
	// Par�metros: valor, el valor com�n  que se escribir� en todos  
	//					los nodos (por defecto, VALOR_DEF_LISTA)

	void Ecualiza (const TipoBaseLista valor=VALOR_DEF_LISTA);

    /***********************************************************************/
    // Busca la posici�n de un valor. 
    // Par�metros: valor, el valor buscado. 
    // Devuelve la posici�n del primer valor coincidente con "valor", 
    //      o -1 si no se encuentra.
    // Posiciones: 1, 2, ..., Tamanio()
    /***********************************************************************/

	int Buscar (TipoBaseLista valor) const;

	/***********************************************************************/
	// Inserta un nuevo elemento en la posici�n "pos_insertar"
	// PRE: 1 <= pos_insertar <= tamanio+1
	// El criterio seguido para especificar una posicion ser� : 
	// 1 -> primero, 2 -> segundo,...
	// Nota: Si pos_insertar == tamanio+1, el resultado es id�ntico a la 
	// 		 ejecuci�n del m�todo Aniade()

	void Inserta (int TipoBaseLista, int pos_insertar);

	/***********************************************************************/
	// Borra el elemento de la posici�n "pos_borrar" 
	// PRE: 1 <= pos_borrar <= tamanio
	// El criterio seguido para especificar una posicion ser� : 
	// 1 -> primero, 2 -> segundo,...

	void Elimina (int pos_borrar);

	/***********************************************************************/
	/***********************************************************************/
	// Devuelve un string con el resultado de "serializar" una lista.
	// Par�metros: msg, mensaje que precede al contenido de la lista. 

	string ToString (const char * const msg); 
				
	/***********************************************************************/
	// Operador de asignaci�n

	Lista & operator = (const Lista & otro);
	Lista & operator = (const TipoBaseLista & valor);

	/***********************************************************************/
	/***********************************************************************/
	// Metodo de acceso individual a elementos: operator [] y operator()
	// Metodo de escritura / lectura
	// Si se utiliza como rvalue se emplea para consulta. Si se utiliza  
	// como lvalue se emplea para modificaci�n.
	//
	// Par�metros: pos, la posici�n (n�mero de nodo) a la que se accede.  	
	// 		El criterio seguido para especificar una posicion ser� : 
	// 		1 -> primero, 2 -> segundo,...
	//
	// PRE: 1 <= posicion <= Tamanio() 		

	TipoBaseLista & operator [] (const int posicion);  	
	TipoBaseLista & operator [] (const int posicion) const;  
	
	TipoBaseLista & operator () (const int posicion);
	TipoBaseLista & operator () (const int posicion) const;  

	/***********************************************************************/
	// Operadores combinados

	// A�ade "valor", un dato TipoBaseLista al final de la lista

	Lista & operator += (const TipoBaseLista valor);


	// Elimina la primera aparici�n de "valor" en la lista
	// Si "valor" no est� en la lista no se hace nada.  
	
	Lista & operator -= (const TipoBaseLista valor);

	/***********************************************************************/
	// Operadores binarios de adici�n y borrado

	// Operador binario +
	//
	// Calcula y devuelve una NUEVA Lista: 
	//
	//	Versi�n 1: [Lista] + [Lista] 
	//			    Concatena las dos Lista en una nueva. Los nodos de la 
	//				segunda se a�aden (en el mismo orden en una copia de la 
	//				primera)   
	//	Versi�n 2: [Lista] + [TipoBaseLista] 
	//			    A�ade un dato TipoBaseLista al final de una copia 
	//				de la Lista.
	//	Versi�n 3: [TipoBaseLista] + [Lista] 
	//			    Inserta el dato TipoBaseLista al principio de una copia 
	//				de Lista.
	// Las listas NO se modifican.

	friend Lista  operator + (const Lista & l1, const Lista & l2);	
	friend Lista  operator + (const Lista & l, const TipoBaseLista valor);
	friend Lista  operator + (const TipoBaseLista valor, const Lista & l);

	// Operador binario -
	//
	// Calcula y devuelve una NUEVA Lista: 
	//
	//	Versi�n 1: [Lista] - [Lista] 
	//			    Elimina de una copia de la primera lista la primera 
	//				ocurrencia de todos los valores que est�n en la segunda.
	//	Versi�n 2: [Lista] - [TipoBaseLista] 
	//			    Elimina de de una copia de la lista la primera ocurrencia 
	//				del valor dado.
	// Los dos datos Lista NO se modifican.

	Lista  operator - (const Lista & otro);		
	Lista  operator - (const TipoBaseLista valor);

	/***********************************************************************/
	// Operadores relacionales
	// Se sigue el criterio de orden de una cadena cl�sica 

	bool operator == (const Lista & otro) const; 
	bool operator != (const Lista & otro) const; 
	bool operator >  (const Lista & otro) const; 
	bool operator <  (const Lista & otro) const; 
	bool operator >= (const Lista & otro) const; 
	bool operator <= (const Lista & otro) const; 
	
	/***********************************************************************/

private:
	

	/***********************************************************************/
	// Pide memoria para "num_elementos" nodos
	// PRE: num_elementos > 0

	void ReservarMemoria (int num_elementos);

	/***********************************************************************/
	// Liberar memoria
	
	void LiberarMemoria (void); 

	/***********************************************************************/
    // Copiar datos desde otro objeto de la clase
	// PRE: Se ha reservado memoria para los datos
	
	void CopiarDatos (const Lista & otro);

	/***********************************************************************/
	// M�todo PRIVADO compartido por: 
	// 		TipoBaseLista & operator[] (int pos);
	// 		TipoBaseLista & operator[] (int pos) const;
	// para evitar la duplicidd de c�digo.
	// 
	// Devuelve una referencia al campo info de un nodo, dado por su posici�n. 
	//
	// Par�metros: pos, la posici�n (n�mero de nodo) a la que se accede.  	
	// 		El criterio seguido para especificar una posicion ser� : 
	// 		1 -> primero, 2 -> segundo,...

	TipoBaseLista & el_valor (int pos) const;

    /***********************************************************************/
    // A�ade un elemento a la lista.
    // El nuevo elemento se coloca al final.

    void AniadeValor (const TipoBaseLista nuevo);

    /***********************************************************************/
    // Borra la primera aparici�n del valor "valor" 

    void EliminarValor (TipoBaseLista valor);

    /***********************************************************************/

};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

// Muestra el contenido de una lista 
void PintaLista (const Lista & l, const char * const msg);

/***************************************************************************/
/***************************************************************************/

#endif

