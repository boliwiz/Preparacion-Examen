/***************************************************************************/
/***************************************************************************/
// METODOLOGÍA DE LA PROGRAMACIÓN
// GRADO EN INGENIERÍA INFORMÁTICA
//
// (C) FRANCISCO JOSÉ CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL
//
// RELACIÓN DE PROBLEMAS 4
//	
//	Declaración de la clase Polilinea (versión 2).
//
//	Fichero: Polilinea.h
//
/***************************************************************************/
/***************************************************************************/

#ifndef POLILINEA
#define POLILINEA

#include "Punto2D.h"

using namespace std;

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

class PoliLinea 
{
private:

	// Los datos se almacenan en un vector dinámico de datos 
	// "Punto2D". Se accede a ellos a través del puntero "datos". 
	// El número de casillas ocupadas se guarda en "usados".

		
	Punto2D * datos;  // Acceso al vector dinámico de datos Punto2D.
	int       usados; // Número de casillas usadas.

	// PRE: 0 <= usados

	// Tipo de redimensionamiento activo. Puede modificarse el tipo 
	// de redimensionamiento en tiempo de ejecución.

public:
	
	/***********************************************************************/
	// Constructor sin argumentos. Crea una PoliLinea vacía
	
	PoliLinea (void);

	/***********************************************************************/
	// Constructor a partir de un punto. 
	// Recibe: nuevo_punto, el único punto que forma la nueva PoliLinea. 
	
	PoliLinea (const Punto2D & nuevo_punto);

	/***********************************************************************/
	// Constructor de copia

	PoliLinea (const PoliLinea & otro);
	
	/***********************************************************************/	
	// Destructor

	~PoliLinea (void);

	/***********************************************************************/
	// Devuelve el número de puntos que componen la Polilinea.

	int NumPuntos (void) const;

	/***********************************************************************/
	// Consulta si la Polilinea está vacía

	bool EstaVacia (void) const;

	/***********************************************************************/
	// Elimina todos los datos Punto2D de la Polilinea. Queda vacía.

	void EliminaTodos (void);

	/***********************************************************************/
	// Serializar un dato PoliLinea.

	string ToString (void) const; 

	/***********************************************************************/
	// Operador de asignación. 
	// Método para hacer una copia profunda desde la PoliLinea explícita 
	// "otra" en la PoliLinea implícita.
	// Parámetros: otra (referencia), referencia al objeto explícito
	// El contenido de la Polilinea implícita se pierde, se sustituye por una  
	// copia del contenido de "otra". 

	PoliLinea & operator = (const PoliLinea & otra);
	
	/***********************************************************************/
	// Metodo de acceso individual a elementos: Operador []
	// Metodo de escritura / lectura
	// Parámetros: indice, la posición a la que se accede.  	
	// Consulta ó modifica el valor de un componente de la Polilinea dado 
	// por su posición (para devolver un Punto2D o sustituirlo por otro).  
	// Si se utiliza como rvalue se emplea para consulta. Si se utiliza  
	// como lvalue se emplea para modificación.
	// Devuelve una referencia al dato Punto2D que está en la casilla "indice".
	//
	// PRE: 1 <= indice <= usados

	Punto2D & operator[] (const int indice);
	Punto2D & operator[] (const int indice) const; 

	/***********************************************************************/
	// Operadores que calculan si dos PoliLinea son iguales/distintas.
	// Dos datos PoliLinea son iguales si tienen los mismos puntos y están 
	// en el mismo orden, independientemente de que se empiece por el primero 
	// o el último. 
	// Parámetros: otra (referencia), la PoliLinea que se quiere comparar  
	//		con el objeto implícito. 
	// Devuelve: true, si son iguales (operator ==) los dos objetos.
	// Devuelve: true, si son distintos (operator !=) los dos objetos.

	bool operator == (const PoliLinea & otra) const;
	bool operator != (const PoliLinea & otra) const; 

	/***********************************************************************/
	// Operador combinado +=
	// Añade un Punto2D a la Polilinea.
	// Parámetros: nuevo_punto (referencia), el punto que se va a añadir.
	// Devuelve: una referencia a la matriz implícita modificada.

	PoliLinea & operator += (const Punto2D & nuevo_punto);

	/***********************************************************************/
	/***********************************************************************/
	// Operador binario +
	//
	// Calcula y devuelve una NUEVA PoliLinea: 
	//
	//	Versión 1: [PoliLinea] + [PoliLinea] 
	//			    Concatena las dos PoliLinea en una nueva. Los puntos de la 
	//				segunda se añaden (en el mismo orden en una copia de la 
	//				primera)   
	//	Versión 2: [PoliLinea] + [Punto2D] 
	//			    Añade el Punto2D al final de una copia de la PoliLinea.
	//	Versión 3: [Punto2D] + [PoliLinea] 
	//			    Inserta el Punto2D al principio de una copia de PoliLinea.
	// Los dos datos PoliLinea NO se modifican (ni el Punto2D).

	friend PoliLinea operator + (const PoliLinea & p1, const PoliLinea & p2);
	friend PoliLinea operator + (const PoliLinea & pol, const Punto2D & punto);
	friend PoliLinea operator + (const Punto2D & punto, const PoliLinea & pol);
					

	/***********************************************************************/	
	/***********************************************************************/
	// MÉTODOS DE E/S
	/***********************************************************************/
	/***********************************************************************/

	/***********************************************************************/
	// Toma de un flujo de entrada (cin) el contenido de una PoliLinea.

	void FromText (void); 

	/***********************************************************************/
	// Inserta en un flujo de salida (cout) el contenido de una PoliLinea.

	void ToText (void) const; 

	/***********************************************************************/

private:

	/***********************************************************************/
	/***********************************************************************/
	// Petición / liberación de memoria

	void ReservarMemoria (const int num_casillas);
	void LiberarMemoria (void);

	/***********************************************************************/
	/***********************************************************************/
	// Copiar datos desde otro objeto de la clase

	void CopiarDatos (const PoliLinea & otro);

	/***********************************************************************/
	/***********************************************************************/
	// Método PRIVADO compartido por: 
	// 		Punto2D & Valor (const int indice);
	// 		Punto2D & Valor (const int indice) const;
	// para evitar la duplicidd de código.
	// 
	// Devuelve una referencia a un dato Punto2D de la PoliLinea, 
	//da su posición. 
	//
	// PRE: 1 <= indice <= usados

	Punto2D & el_valor (int indice) const;

	/***********************************************************************/
	/***********************************************************************/
	// Calcula si dos PoliLinea son iguales 
	// Dos datos PoliLinea son iguales si tienen los mismos puntos y están 
	// en el mismo orden, independientemente de que se empiece por el primero 
	// o el último. 
	// Parámetros: otra (referencia), la PoliLinea que se quiere comparar  
	//		con el objeto implícito. 
	// Devuelve: true, si se consideran iguales los dos objetos.

	bool EsIgualA (const PoliLinea & otra) const;

	/***********************************************************************/
	/***********************************************************************/
	// Añade un Punto2D a la Polilinea.
	// Parámetros: nuevo_punto (referencia), el punto que se va a añadir.

	void Aniade (const Punto2D & nuevo_punto);

	/***********************************************************************/
	/***********************************************************************/
};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


#endif
